#!/usr/bin/env bash
#
# snapshot.sh - capture the live repository (browser-uploaded tools + metadata)
#               back into this package, so the next deploy re-seeds them.
#
# Run this BEFORE the environment is wiped to persist anything added during a
# class. It copies /opt/armory/data/tools/* into ./tools and the live manifest
# into ./manifest.seed.json. Then re-zip / commit the package.
#
# Usage:
#   sudo ./snapshot.sh
#
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/armory}"
DATA_DIR="${DATA_DIR:-$INSTALL_DIR/data}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say() { printf '\033[1;36m[armory]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[armory] ERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[ -d "$DATA_DIR/tools" ] || die "no live repository at $DATA_DIR/tools"

mkdir -p "$SRC/tools"
n=0
shopt -s nullglob
for f in "$DATA_DIR"/tools/*; do
  [ -f "$f" ] || continue
  cp -a "$f" "$SRC/tools/"
  n=$((n+1))
done
shopt -u nullglob

if [ -f "$DATA_DIR/manifest.json" ]; then
  cp -a "$DATA_DIR/manifest.json" "$SRC/manifest.seed.json"
fi

say "captured $n tool(s) into $SRC/tools and refreshed manifest.seed.json"
say "re-package (zip the folder) or commit to persist across the wipe."
