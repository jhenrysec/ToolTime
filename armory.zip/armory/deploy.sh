#!/usr/bin/env bash
#
# deploy.sh - install ARMORY (tool repository) on Ubuntu 20.04 LTS and
#             create + enable + start its systemd service.
#
# Designed for environments that wipe between classes: re-extract the package
# and re-run this script. Any files in ./tools (and ./manifest.seed.json) are
# seeded into the repository on deploy. Use ./snapshot.sh to capture
# browser-uploaded tools back into the package before a wipe.
#
# Usage (run as root from the extracted package directory):
#   sudo ./deploy.sh
#   sudo PORT=80 ./deploy.sh
#
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/armory}"
DATA_DIR="${DATA_DIR:-$INSTALL_DIR/data}"
SVC_USER="${SVC_USER:-armory}"
PORT="${PORT:-8080}"
BIND="${BIND:-0.0.0.0}"
MAX_UPLOAD_MB="${MAX_UPLOAD_MB:-1024}"
ASSET_CACHE_DAYS="${ASSET_CACHE_DAYS:-30}"

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || true)"

say()  { printf '\033[1;36m[armory]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[armory]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[armory] ERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root (sudo $0)"
[ -n "$PY" ] || die "python3 not found (Ubuntu 20.04 ships 3.8; apt-get install python3)"
[ -f "$SRC/server.py" ] || die "server.py not found next to deploy.sh"

# service account
if ! id -u "$SVC_USER" >/dev/null 2>&1; then
  say "creating service user '$SVC_USER'"
  useradd --system --no-create-home --shell /usr/sbin/nologin "$SVC_USER"
fi

say "installing into $INSTALL_DIR"
install -d -m 0755 "$INSTALL_DIR" "$INSTALL_DIR/assets" "$DATA_DIR" "$DATA_DIR/tools"
install -m 0644 "$SRC/server.py" "$INSTALL_DIR/server.py"

# assets (seal + anything else under assets/)
if [ -d "$SRC/assets" ]; then
  cp -a "$SRC/assets/." "$INSTALL_DIR/assets/"
fi
[ -f "$INSTALL_DIR/assets/uscybercom.svg" ] || warn "assets/uscybercom.svg missing (splash logo will be hidden)"

# seed tools (without clobbering anything already in the live repo)
if [ -d "$SRC/tools" ]; then
  shopt -s nullglob dotglob
  seeded=0
  for f in "$SRC"/tools/*; do
    [ -f "$f" ] || continue
    base="$(basename "$f")"
    if [ ! -e "$DATA_DIR/tools/$base" ]; then
      install -m 0644 "$f" "$DATA_DIR/tools/$base"
      seeded=$((seeded+1))
    fi
  done
  shopt -u nullglob dotglob
  [ "$seeded" -gt 0 ] && say "seeded $seeded tool(s) from package"
fi

# merge seed metadata into the live manifest (seed fills gaps; live wins)
if [ -f "$SRC/manifest.seed.json" ]; then
  say "merging seed manifest metadata"
  "$PY" - "$DATA_DIR/manifest.json" "$SRC/manifest.seed.json" <<'PYEOF'
import json, os, sys
live_path, seed_path = sys.argv[1], sys.argv[2]
live = {"tools": {}}
if os.path.exists(live_path):
    try: live = json.load(open(live_path))
    except Exception: pass
live.setdefault("tools", {})
seed = json.load(open(seed_path))
for name, meta in seed.get("tools", {}).items():
    live["tools"].setdefault(name, meta)   # don't overwrite live entries
json.dump(live, open(live_path, "w"), indent=2)
PYEOF
fi

chown -R "$SVC_USER":"$SVC_USER" "$INSTALL_DIR"

say "writing /etc/systemd/system/armory.service"
cat > /etc/systemd/system/armory.service <<EOF
[Unit]
Description=ARMORY tool repository
After=network.target

[Service]
Type=simple
User=$SVC_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$PY $INSTALL_DIR/server.py --port $PORT --bind $BIND \\
  --data $DATA_DIR --assets $INSTALL_DIR/assets --max-upload-mb $MAX_UPLOAD_MB \\
  --asset-cache-days $ASSET_CACHE_DAYS
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now armory.service

echo
say "service status: $(systemctl is-active armory.service 2>/dev/null || echo unknown)"
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; [ -n "${IP:-}" ] || IP="<this-host-ip>"
say "ARMORY is up at:  http://$IP:$PORT/"
say "tools dir:        $DATA_DIR/tools   (drop files here or upload via the page)"
say "logs:             journalctl -u armory -f"
