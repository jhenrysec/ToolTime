#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARMORY - tool repository server
===============================

A self-hosted download portal for distributing tools across an isolated
network. Dynamic: tools are read from a directory at request time, so files
added by hand or uploaded through the browser appear immediately. Includes
search, categories, browser upload (drag-and-drop), and delete.

  * Standard-library Python only (no pip).  Python 3.8+ (Ubuntu 20.04 LTS).
  * No internet required; all assets served locally.
  * Built for Firefox 115 (modern ES2020+ client).

Layout (relative to this file, override with flags):
    ./assets/        static assets (the seal SVG, etc.)
    ./data/tools/    the downloadable files
    ./data/manifest.json   per-file metadata {category, description, version}
"""

import argparse
import email.utils
import json
import os
import re
import shutil
import socket
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

BASE = os.path.dirname(os.path.abspath(__file__))
CFG = {
    "assets": os.path.join(BASE, "assets"),
    "data": os.path.join(BASE, "data"),
    "max_upload_mb": 1024,
    "asset_max_age": 30 * 86400,   # static-asset freshness (seconds); ~30 days
}


def tools_dir():
    return os.path.join(CFG["data"], "tools")


def manifest_path():
    return os.path.join(CFG["data"], "manifest.json")


def ensure_dirs():
    os.makedirs(tools_dir(), exist_ok=True)
    os.makedirs(CFG["assets"], exist_ok=True)
    if not os.path.exists(manifest_path()):
        save_manifest({"tools": {}})


def load_manifest():
    try:
        with open(manifest_path(), "r", encoding="utf-8") as f:
            m = json.load(f)
            if "tools" not in m:
                m["tools"] = {}
            return m
    except Exception:
        return {"tools": {}}


def save_manifest(m):
    tmp = manifest_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(m, f, indent=2)
    os.replace(tmp, manifest_path())


SAFE_RE = re.compile(r"[^A-Za-z0-9._+\- ]+")


def safe_name(name):
    name = os.path.basename(unquote(name or "")).strip()
    name = SAFE_RE.sub("_", name)
    name = name.strip(". ")
    if not name or name in (".", "..") or len(name) > 200:
        raise ValueError("invalid filename")
    return name


def human_size(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024.0:
            return ("%.0f %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0
    return "%.1f PB" % n


def etag_for(st):
    """Cheap, correct validator from size + mtime (no hashing large files)."""
    return '"%x-%x"' % (st.st_size, int(st.st_mtime))


def http_date(ts):
    return email.utils.formatdate(ts, usegmt=True)


def list_tools():
    m = load_manifest()
    meta = m.get("tools", {})
    out = []
    cats = set()
    for fn in sorted(os.listdir(tools_dir())):
        full = os.path.join(tools_dir(), fn)
        if not os.path.isfile(full) or fn.startswith("."):
            continue
        st = os.stat(full)
        info = meta.get(fn, {})
        cat = (info.get("category") or "Uncategorized").strip() or "Uncategorized"
        cats.add(cat)
        out.append({
            "name": fn,
            "size": st.st_size,
            "size_h": human_size(st.st_size),
            "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
            "modified_ts": int(st.st_mtime),
            "category": cat,
            "description": (info.get("description") or "").strip(),
            "version": (info.get("version") or "").strip(),
        })
    return out, sorted(cats)


# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "Armory/1.0"

    def log_message(self, *a):
        pass

    # -- helpers ----------------------------------------------------------
    def _send(self, code, ctype, body, extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body) if body is not None else 0))
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        if body is not None and self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, "application/json", json.dumps(obj),
                   {"Cache-Control": "no-store"})

    def _fresh(self, etag, mtime):
        """True if the client's cached copy is still valid (-> 304)."""
        inm = self.headers.get("If-None-Match")
        if inm:
            if etag in [t.strip() for t in inm.split(",")]:
                return True
        ims = self.headers.get("If-Modified-Since")
        if ims:
            try:
                ims_ts = email.utils.parsedate_to_datetime(ims).timestamp()
                if int(mtime) <= int(ims_ts):
                    return True
            except Exception:
                pass
        return False

    def _send_304(self, etag):
        self.send_response(304)
        self.send_header("ETag", etag)
        self.end_headers()

    # -- routing ----------------------------------------------------------
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        if path == "/" or path == "/index.html":
            self._send(200, "text/html; charset=utf-8", PAGE,
                       {"Cache-Control": "no-cache"})
        elif path == "/api/tools":
            tools, cats = list_tools()
            self._json(200, {"host": socket.gethostname(),
                             "count": len(tools), "categories": cats, "tools": tools})
        elif path == "/health":
            self._send(200, "text/plain", "OK")
        elif path.startswith("/assets/"):
            self._serve_asset(path[len("/assets/"):])
        elif path.startswith("/download/"):
            self._download(path[len("/download/"):])
        else:
            self._send(404, "text/plain", "not found")

    def do_HEAD(self):
        self.do_GET()

    def do_PUT(self):
        u = urlparse(self.path)
        if not u.path.startswith("/upload/"):
            self._json(404, {"error": "not found"})
            return
        try:
            name = safe_name(u.path[len("/upload/"):])
        except ValueError:
            self._json(400, {"error": "invalid filename"})
            return
        length = int(self.headers.get("Content-Length", 0))
        if length <= 0:
            self._json(400, {"error": "empty body"})
            return
        if length > CFG["max_upload_mb"] * 1024 * 1024:
            self._json(413, {"error": "file too large"})
            return

        dest = os.path.join(tools_dir(), name)
        tmp = dest + ".part"
        remaining = length
        try:
            with open(tmp, "wb") as f:
                while remaining > 0:
                    chunk = self.rfile.read(min(65536, remaining))
                    if not chunk:
                        break
                    f.write(chunk)
                    remaining -= len(chunk)
            os.replace(tmp, dest)
        except Exception as e:
            try:
                os.remove(tmp)
            except OSError:
                pass
            self._json(500, {"error": "write failed: %s" % e})
            return

        q = parse_qs(u.query)
        m = load_manifest()
        m["tools"][name] = {
            "category": (q.get("category", [""])[0]).strip() or "Uncategorized",
            "description": (q.get("description", [""])[0]).strip(),
            "version": (q.get("version", [""])[0]).strip(),
            "added": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        save_manifest(m)
        self._json(200, {"ok": True, "name": name})

    def do_DELETE(self):
        u = urlparse(self.path)
        if not u.path.startswith("/tool/"):
            self._json(404, {"error": "not found"})
            return
        try:
            name = safe_name(u.path[len("/tool/"):])
        except ValueError:
            self._json(400, {"error": "invalid filename"})
            return
        full = os.path.join(tools_dir(), name)
        if not os.path.isfile(full):
            self._json(404, {"error": "no such tool"})
            return
        try:
            os.remove(full)
        except OSError as e:
            self._json(500, {"error": str(e)})
            return
        m = load_manifest()
        m["tools"].pop(name, None)
        save_manifest(m)
        self._json(200, {"ok": True})

    # -- file serving -----------------------------------------------------
    def _serve_asset(self, rel):
        try:
            name = safe_name(rel)
        except ValueError:
            self._send(400, "text/plain", "bad name")
            return
        full = os.path.join(CFG["assets"], name)
        if not os.path.isfile(full):
            self._send(404, "text/plain", "not found")
            return
        st = os.stat(full)
        etag = etag_for(st)
        # Long freshness window so assets are not re-fetched during a class;
        # ETag/Last-Modified let the browser revalidate cheaply (304) after.
        if self._fresh(etag, st.st_mtime):
            self._send_304(etag)
            return
        ctype = "image/svg+xml" if name.lower().endswith(".svg") else \
            "image/png" if name.lower().endswith(".png") else \
            "image/jpeg" if name.lower().endswith((".jpg", ".jpeg")) else \
            "application/octet-stream"
        with open(full, "rb") as f:
            data = f.read()
        self._send(200, ctype, data, {
            "Cache-Control": "public, max-age=%d" % CFG["asset_max_age"],
            "ETag": etag,
            "Last-Modified": http_date(st.st_mtime),
        })

    def _download(self, rel):
        try:
            name = safe_name(rel)
        except ValueError:
            self._send(400, "text/plain", "bad name")
            return
        full = os.path.join(tools_dir(), name)
        if not os.path.isfile(full):
            self._send(404, "text/plain", "not found")
            return
        st = os.stat(full)
        etag = etag_for(st)
        # Tools can be replaced/removed, so revalidate every time rather than
        # caching long -- but a re-download of an *unchanged* tool returns 304.
        if self._fresh(etag, st.st_mtime):
            self._send_304(etag)
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(st.st_size))
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % name)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("ETag", etag)
        self.send_header("Last-Modified", http_date(st.st_mtime))
        self.end_headers()
        if self.command != "HEAD":
            with open(full, "rb") as f:
                shutil.copyfileobj(f, self.wfile, 65536)


# --------------------------------------------------------------------------
PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ARMORY</title>
<style>
  :root{
    --bg:#0a0d13; --bg2:#0e131c; --panel:#121823; --panel2:#161d2a;
    --border:#243044; --border2:#2e3c52;
    --text:#e7edf5; --muted:#8a99ad; --faint:#5d6b80;
    --gold:#c8a951; --gold2:#e2c878; --steel:#5b8fc7; --steel2:#7fb0e0;
    --red:#d9534f; --green:#46b56a;
    --radius:10px;
  }
  *{box-sizing:border-box;}
  html,body{margin:0;height:100%;}
  body{
    background:radial-gradient(1200px 600px at 50% -200px, #16243a 0%, var(--bg) 55%) fixed, var(--bg);
    color:var(--text);
    font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;
    line-height:1.5;
  }
  .mono{font-family:ui-monospace,"Cascadia Code",Consolas,"DejaVu Sans Mono",monospace;}
  a{color:var(--steel2);text-decoration:none;}

  /* hero */
  header.hero{
    text-align:center; padding:44px 20px 26px; position:relative;
    border-bottom:1px solid var(--border);
    background:linear-gradient(180deg, rgba(20,30,48,0.55), rgba(10,13,19,0));
  }
  header.hero img{
    width:150px;height:150px;
    filter:drop-shadow(0 6px 24px rgba(0,0,0,0.6));
  }
  header.hero h1{
    margin:14px 0 2px; font-size:30px; letter-spacing:10px; font-weight:700;
    color:#f3f6fb;
  }
  header.hero .sub{
    color:var(--gold); letter-spacing:5px; font-size:12px; text-transform:uppercase;
  }
  header.hero .host{ color:var(--faint); font-size:12px; margin-top:8px; }
  .rule{height:2px;width:120px;margin:14px auto 0;
        background:linear-gradient(90deg,transparent,var(--gold),transparent);}

  .wrap{max-width:1180px;margin:0 auto;padding:22px 20px 64px;}

  /* controls */
  .controls{
    display:flex;gap:12px;align-items:center;flex-wrap:wrap;
    margin-bottom:16px;
  }
  .search{flex:1 1 320px;position:relative;}
  .search input{
    width:100%;background:var(--panel);border:1px solid var(--border2);
    color:var(--text);border-radius:var(--radius);padding:12px 14px 12px 40px;
    font-size:15px;outline:none;
  }
  .search input:focus{border-color:var(--steel);box-shadow:0 0 0 3px rgba(91,143,199,0.15);}
  .search svg{position:absolute;left:13px;top:12px;width:18px;height:18px;fill:var(--faint);}
  select,.btn{
    background:var(--panel);border:1px solid var(--border2);color:var(--text);
    border-radius:var(--radius);padding:11px 14px;font-size:14px;cursor:pointer;
  }
  .btn.primary{background:linear-gradient(180deg,#caa84e,#b8923a);color:#1a140a;
               border:none;font-weight:700;letter-spacing:.5px;}
  .btn.primary:hover{filter:brightness(1.07);}
  .btn:hover{border-color:var(--steel);}

  /* category chips */
  .chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px;}
  .chip{
    background:var(--panel);border:1px solid var(--border);color:var(--muted);
    padding:6px 13px;border-radius:999px;font-size:13px;cursor:pointer;user-select:none;
  }
  .chip.active{background:rgba(200,169,81,0.16);border-color:var(--gold);color:var(--gold2);}
  .chip:hover{border-color:var(--gold);}

  .count{color:var(--faint);font-size:13px;margin:0 0 12px;}

  /* grid */
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px;}
  .card{
    background:linear-gradient(180deg,var(--panel2),var(--panel));
    border:1px solid var(--border);border-radius:var(--radius);
    padding:16px 16px 14px;display:flex;flex-direction:column;gap:10px;
    transition:border-color .15s, transform .15s;
  }
  .card:hover{border-color:var(--border2);transform:translateY(-2px);}
  .card .top{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;}
  .card .name{font-weight:600;font-size:15px;word-break:break-word;}
  .badge{font-size:11px;padding:3px 9px;border-radius:999px;white-space:nowrap;
         background:rgba(91,143,199,0.15);color:var(--steel2);border:1px solid rgba(91,143,199,0.3);}
  .card .desc{color:var(--muted);font-size:13px;min-height:18px;}
  .card .meta{color:var(--faint);font-size:12px;display:flex;gap:14px;flex-wrap:wrap;}
  .card .actions{display:flex;gap:8px;margin-top:4px;}
  .dl{flex:1;text-align:center;background:var(--panel);border:1px solid var(--steel);
      color:var(--steel2);border-radius:8px;padding:9px;font-weight:600;font-size:13px;}
  .dl:hover{background:rgba(91,143,199,0.14);}
  .del{background:transparent;border:1px solid var(--border2);color:var(--faint);
       border-radius:8px;padding:9px 11px;cursor:pointer;}
  .del:hover{border-color:var(--red);color:var(--red);}

  .empty{text-align:center;color:var(--faint);padding:70px 20px;border:1px dashed var(--border2);
         border-radius:var(--radius);}

  /* upload dialog */
  dialog{
    background:var(--panel);color:var(--text);border:1px solid var(--border2);
    border-radius:14px;padding:0;max-width:560px;width:92vw;
  }
  dialog::backdrop{background:rgba(4,7,12,0.7);}
  .dlg-hd{padding:18px 20px;border-bottom:1px solid var(--border);font-size:18px;font-weight:700;letter-spacing:1px;}
  .dlg-bd{padding:20px;}
  .drop{
    border:2px dashed var(--border2);border-radius:12px;padding:30px;text-align:center;
    color:var(--muted);cursor:pointer;transition:.15s;
  }
  .drop.hot{border-color:var(--gold);background:rgba(200,169,81,0.07);color:var(--gold2);}
  .field{margin-top:14px;}
  .field label{display:block;font-size:12px;color:var(--faint);margin-bottom:5px;letter-spacing:.5px;text-transform:uppercase;}
  .field input{width:100%;background:var(--bg2);border:1px solid var(--border2);color:var(--text);
               border-radius:8px;padding:10px 12px;font-size:14px;outline:none;}
  .field input:focus{border-color:var(--steel);}
  .queue{margin-top:14px;display:flex;flex-direction:column;gap:8px;max-height:200px;overflow:auto;}
  .qitem{font-size:13px;background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:9px 11px;}
  .bar{height:5px;background:var(--border);border-radius:4px;margin-top:7px;overflow:hidden;}
  .bar > i{display:block;height:100%;width:0;background:var(--gold);transition:width .12s;}
  .qitem.ok{border-color:rgba(70,181,106,0.5);} .qitem.ok .bar>i{background:var(--green);}
  .qitem.err{border-color:rgba(217,83,79,0.6);color:var(--red);}
  .dlg-ft{padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px;}

  /* toast */
  #toast{position:fixed;right:18px;bottom:18px;display:flex;flex-direction:column;gap:8px;z-index:50;}
  .toast{background:var(--panel2);border:1px solid var(--border2);border-left:4px solid var(--steel);
         padding:11px 15px;border-radius:8px;font-size:14px;box-shadow:0 8px 24px rgba(0,0,0,.4);
         animation:slide .2s ease-out;}
  .toast.ok{border-left-color:var(--green);} .toast.err{border-left-color:var(--red);}
  @keyframes slide{from{transform:translateY(8px);opacity:0;}to{transform:none;opacity:1;}}

  footer{text-align:center;color:var(--faint);font-size:12px;padding:24px;border-top:1px solid var(--border);}
</style>
</head>
<body>
<header class="hero">
  <img src="/assets/uscybercom.svg" alt="seal" onerror="this.style.display='none'">
  <h1>ARMORY</h1>
  <div class="sub">Tool Repository</div>
  <div class="host" id="host"></div>
  <div class="rule"></div>
</header>

<div class="wrap">
  <div class="controls">
    <div class="search">
      <svg viewBox="0 0 24 24"><path d="M21 20l-5.6-5.6a7 7 0 10-1.4 1.4L20 21zM5 10a5 5 0 1110 0 5 5 0 01-10 0z"/></svg>
      <input id="q" type="search" placeholder="Search tools by name, description, or category..." autocomplete="off">
    </div>
    <select id="sort">
      <option value="name">Name (A-Z)</option>
      <option value="modified">Newest</option>
      <option value="size">Size</option>
    </select>
    <button class="btn primary" id="uploadBtn">+ Upload</button>
  </div>

  <div class="chips" id="chips"></div>
  <p class="count" id="count"></p>
  <div class="grid" id="grid"></div>
</div>

<dialog id="dlg">
  <div class="dlg-hd">Upload tools</div>
  <div class="dlg-bd">
    <div class="drop" id="drop">
      <div style="font-size:15px;">Drop files here or <span style="color:var(--gold2)">browse</span></div>
      <div style="font-size:12px;margin-top:6px;color:var(--faint)">multiple files supported</div>
    </div>
    <input type="file" id="file" multiple hidden>
    <div class="field"><label>Category (optional)</label><input id="cat" placeholder="e.g. Recon, Persistence, C2"></div>
    <div class="field"><label>Description (optional)</label><input id="desc" placeholder="Short description applied to this batch"></div>
    <div class="field"><label>Version (optional)</label><input id="ver" placeholder="e.g. 1.0"></div>
    <div class="queue" id="queue"></div>
  </div>
  <div class="dlg-ft">
    <button class="btn" id="closeDlg">Close</button>
  </div>
</dialog>

<div id="toast"></div>

<script>
"use strict";
const $ = (s) => document.querySelector(s);
const state = { tools: [], categories: [], cat: "all", q: "", sort: "name" };

document.getElementById("host").textContent = location.hostname + " :: " + location.host;

function toast(msg, kind="ok"){
  const t = document.createElement("div");
  t.className = "toast " + kind;
  t.textContent = msg;
  $("#toast").appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

async function load(){
  try{
    const r = await fetch("/api/tools", {cache:"no-store"});
    const d = await r.json();
    state.tools = d.tools;
    state.categories = d.categories;
    render();
  }catch(e){
    toast("Could not load tool list", "err");
  }
}

function renderChips(){
  const chips = $("#chips");
  const cats = ["all", ...state.categories];
  chips.innerHTML = "";
  for(const c of cats){
    const el = document.createElement("div");
    el.className = "chip" + (state.cat === c ? " active" : "");
    el.textContent = c === "all" ? "All" : c;
    el.onclick = () => { state.cat = c; render(); };
    chips.appendChild(el);
  }
}

function filtered(){
  const q = state.q.toLowerCase();
  let list = state.tools.filter(t => {
    if(state.cat !== "all" && t.category !== state.cat) return false;
    if(!q) return true;
    return (t.name + " " + t.description + " " + t.category + " " + t.version)
      .toLowerCase().includes(q);
  });
  list.sort((a,b) => {
    if(state.sort === "modified") return b.modified_ts - a.modified_ts;
    if(state.sort === "size") return b.size - a.size;
    return a.name.localeCompare(b.name);
  });
  return list;
}

function render(){
  renderChips();
  const list = filtered();
  $("#count").textContent =
    list.length + " of " + state.tools.length + " tool" + (state.tools.length===1?"":"s");
  const grid = $("#grid");
  grid.innerHTML = "";
  if(list.length === 0){
    grid.innerHTML = '<div class="empty" style="grid-column:1/-1">' +
      (state.tools.length === 0
        ? "No tools available yet. Use <b>+ Upload</b> to add some."
        : "No tools match your search.") + "</div>";
    return;
  }
  for(const t of list){
    const card = document.createElement("div");
    card.className = "card";
    const ver = t.version ? ' <span style="color:var(--faint)">v'+escapeHtml(t.version)+"</span>" : "";
    card.innerHTML =
      '<div class="top"><span class="name mono">'+escapeHtml(t.name)+ver+'</span>'+
      '<span class="badge">'+escapeHtml(t.category)+'</span></div>'+
      '<div class="desc">'+(t.description?escapeHtml(t.description):"&mdash;")+'</div>'+
      '<div class="meta"><span>'+t.size_h+'</span><span>'+t.modified+'</span></div>'+
      '<div class="actions">'+
        '<a class="dl" href="/download/'+encodeURIComponent(t.name)+'">Download</a>'+
        '<button class="del" title="Remove" data-n="'+escapeAttr(t.name)+'">&#10005;</button>'+
      '</div>';
    card.querySelector(".del").onclick = () => removeTool(t.name);
    grid.appendChild(card);
  }
}

function escapeHtml(s){ return (s||"").replace(/[&<>"]/g, c => (
  {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
function escapeAttr(s){ return escapeHtml(s).replace(/'/g,"&#39;"); }

async function removeTool(name){
  if(!confirm("Remove \"" + name + "\" from the repository?")) return;
  try{
    const r = await fetch("/tool/" + encodeURIComponent(name), {method:"DELETE"});
    if(!r.ok) throw 0;
    toast("Removed " + name);
    load();
  }catch(e){ toast("Failed to remove " + name, "err"); }
}

/* search + sort */
$("#q").addEventListener("input", (e) => { state.q = e.target.value; render(); });
$("#sort").addEventListener("change", (e) => { state.sort = e.target.value; render(); });

/* upload dialog */
const dlg = $("#dlg");
$("#uploadBtn").onclick = () => { $("#queue").innerHTML=""; dlg.showModal(); };
$("#closeDlg").onclick = () => dlg.close();
const drop = $("#drop"), fileInput = $("#file");
drop.onclick = () => fileInput.click();
["dragenter","dragover"].forEach(ev => drop.addEventListener(ev, e => {
  e.preventDefault(); drop.classList.add("hot"); }));
["dragleave","drop"].forEach(ev => drop.addEventListener(ev, e => {
  e.preventDefault(); drop.classList.remove("hot"); }));
drop.addEventListener("drop", e => handleFiles(e.dataTransfer.files));
fileInput.addEventListener("change", e => handleFiles(e.target.files));

function handleFiles(files){
  const cat = $("#cat").value, desc = $("#desc").value, ver = $("#ver").value;
  [...files].forEach(f => uploadOne(f, cat, desc, ver));
}

function uploadOne(file, cat, desc, ver){
  const item = document.createElement("div");
  item.className = "qitem";
  item.innerHTML = '<div>'+escapeHtml(file.name)+' <span style="color:var(--faint)">('+
    fmtSize(file.size)+')</span></div><div class="bar"><i></i></div>';
  $("#queue").appendChild(item);
  const bar = item.querySelector(".bar > i");

  const qs = new URLSearchParams({category:cat, description:desc, version:ver}).toString();
  const xhr = new XMLHttpRequest();
  xhr.open("PUT", "/upload/" + encodeURIComponent(file.name) + "?" + qs);
  xhr.upload.onprogress = (e) => {
    if(e.lengthComputable) bar.style.width = (100*e.loaded/e.total) + "%";
  };
  xhr.onload = () => {
    if(xhr.status === 200){
      item.classList.add("ok"); bar.style.width = "100%";
      toast("Uploaded " + file.name);
      load();
    }else{
      item.classList.add("err");
      let msg = "upload failed";
      try{ msg = JSON.parse(xhr.responseText).error || msg; }catch(e){}
      item.querySelector("div").textContent = file.name + " - " + msg;
    }
  };
  xhr.onerror = () => { item.classList.add("err"); };
  xhr.send(file);
}

function fmtSize(n){
  const u=["B","KB","MB","GB"]; let i=0;
  while(n>=1024 && i<u.length-1){ n/=1024; i++; }
  return (i===0? n : n.toFixed(1)) + " " + u[i];
}

load();
setInterval(load, 15000);
</script>
</body>
</html>"""


def main():
    ap = argparse.ArgumentParser(description="ARMORY tool repository server")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--data", default=CFG["data"], help="data dir (tools/ + manifest.json)")
    ap.add_argument("--assets", default=CFG["assets"], help="static assets dir")
    ap.add_argument("--max-upload-mb", type=int, default=CFG["max_upload_mb"])
    ap.add_argument("--asset-cache-days", type=int, default=30,
                    help="how long browsers may cache static assets (default 30)")
    args = ap.parse_args()
    CFG["data"] = os.path.abspath(args.data)
    CFG["assets"] = os.path.abspath(args.assets)
    CFG["max_upload_mb"] = args.max_upload_mb
    CFG["asset_max_age"] = max(0, args.asset_cache_days) * 86400
    ensure_dirs()

    bar = "=" * 64
    print(bar)
    print(" ARMORY :: tool repository")
    print(bar)
    print(" URL    : http://%s:%d/" % (args.bind, args.port))
    print(" Tools  : %s" % tools_dir())
    print(" Assets : %s" % CFG["assets"])
    print(" Limit  : %d MB/upload" % CFG["max_upload_mb"])
    print(" Cache  : assets %d days (revalidated via ETag)" % (CFG["asset_max_age"] // 86400))
    print(bar)
    httpd = ThreadingHTTPServer((args.bind, args.port), Handler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        httpd.shutdown()


if __name__ == "__main__":
    main()
